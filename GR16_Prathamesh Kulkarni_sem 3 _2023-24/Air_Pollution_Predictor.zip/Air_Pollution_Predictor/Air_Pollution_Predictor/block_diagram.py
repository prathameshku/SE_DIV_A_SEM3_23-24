import matplotlib.pyplot as plt
import matplotlib.patches as patches

def create_block_diagram():
    # Create figure and axis
    fig, ax = plt.subplots(figsize=(15, 10))
    
    # Set background color
    ax.set_facecolor('#f0f0f0')
    
    # Title
    plt.title('Air Pollution Predictor System Architecture', pad=20, fontsize=16, fontweight='bold')
    
    # Define colors
    colors = ['#FF9999', '#66B2FF', '#99FF99', '#FFCC99']
    
    # Define box dimensions
    box_width = 0.2
    box_height = 0.1
    spacing = 0.05
    
    # Layer 1: Top Row
    boxes_layer1 = []
    for i in range(3):
        x = 0.2 + i * 0.3
        y = 0.7
        box = patches.Rectangle((x, y), box_width, box_height, facecolor=colors[0], alpha=0.3)
        ax.add_patch(box)
        boxes_layer1.append((x, y))
        plt.text(x + box_width/2, y + box_height/2, 
                ['User Interface', 'Data Input', 'Data Storage'][i],
                ha='center', va='center', fontsize=8)
    
    # Layer 2: Middle Row
    boxes_layer2 = []
    for i in range(3):
        x = 0.2 + i * 0.3
        y = 0.5
        box = patches.Rectangle((x, y), box_width, box_height, facecolor=colors[1], alpha=0.3)
        ax.add_patch(box)
        boxes_layer2.append((x, y))
        plt.text(x + box_width/2, y + box_height/2,
                ['Visualization', 'Data Processing', 'Model Storage'][i],
                ha='center', va='center', fontsize=8)
    
    # Layer 3: Bottom Row
    boxes_layer3 = []
    for i in range(3):
        x = 0.2 + i * 0.3
        y = 0.3
        box = patches.Rectangle((x, y), box_width, box_height, facecolor=colors[2], alpha=0.3)
        ax.add_patch(box)
        boxes_layer3.append((x, y))
        plt.text(x + box_width/2, y + box_height/2,
                ['Health Advice', 'AQI Prediction', 'Alert System'][i],
                ha='center', va='center', fontsize=8)
    
    # Add arrows between layers
    arrow_props = dict(arrowstyle='->', connectionstyle='arc3,rad=0.2')
    
    # Vertical connections
    for i in range(3):
        # Layer 1 to Layer 2
        plt.annotate('', 
                    xy=(boxes_layer1[i][0] + box_width/2, boxes_layer1[i][1]),
                    xytext=(boxes_layer2[i][0] + box_width/2, boxes_layer2[i][1] + box_height),
                    arrowprops=arrow_props)
        
        # Layer 2 to Layer 3
        plt.annotate('',
                    xy=(boxes_layer2[i][0] + box_width/2, boxes_layer2[i][1]),
                    xytext=(boxes_layer3[i][0] + box_width/2, boxes_layer3[i][1] + box_height),
                    arrowprops=arrow_props)
    
    # Horizontal connections within each layer
    for layer in [boxes_layer1, boxes_layer2, boxes_layer3]:
        for i in range(2):
            plt.annotate('',
                        xy=(layer[i][0] + box_width, layer[i][1] + box_height/2),
                        xytext=(layer[i+1][0], layer[i+1][1] + box_height/2),
                        arrowprops=arrow_props)
    
    # Add layer labels
    layer_labels = ['User Interface Layer', 'Processing Layer', 'Storage Layer']
    for i, label in enumerate(layer_labels):
        plt.text(0.5, 0.8 - i*0.2, label, ha='center', va='center', fontsize=10, fontweight='bold')
    
    # Set axis limits and remove axes
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis('off')
    
    # Save the diagram
    plt.savefig('block_diagram.png', dpi=300, bbox_inches='tight')
    plt.close()

if __name__ == "__main__":
    create_block_diagram() 