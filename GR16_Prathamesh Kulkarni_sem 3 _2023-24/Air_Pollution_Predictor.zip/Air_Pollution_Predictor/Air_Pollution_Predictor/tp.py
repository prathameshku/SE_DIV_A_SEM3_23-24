import pandas as pd

aqi_data = pd.read_csv(r'C:\Users\LENOVO\Desktop\Air_Pollution_Detection\location_detection.csv')
print(aqi_data.head())
